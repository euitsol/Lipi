<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admission Submit</title>
</head>
<body>
<section>
    <div>
        <h1 style="text-align: center;color:green">
            Your successfully submited your information.
        </h1>
    </div>
    <br>
    <br>
    <br>
    <div>
        <h1 style="text-align: center;color:green;cursor: pointer" type="button">
            Pay Now
        </h1>
    </div>
</section>
</body>
</html>
